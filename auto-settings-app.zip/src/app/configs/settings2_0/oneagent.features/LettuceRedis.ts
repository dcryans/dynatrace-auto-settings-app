export const LETTUCE_REDIS = [
  {
    summary: "Java Lettuce Redis client \\[Opt\\-In\\]",
    searchSummary: "Java Lettuce Redis client [Opt-In]",
    created: 1687441308304,
    modified: 1687813559403,
    author: "Dynatrace support user #563296671",
    updateToken:
      "vu9U3hXY3q0ATAAkMDY0YjRhMWYtMzMzOS0zNGZkLWEwOTItY2FjZmJjYTRmOGZhACQ0MDBlZDNiMC0xNDY1LTExZWUtODAwMS0wMTAwMDAwMDAwMDG-71TeFdjerQ",
    scope: "environment",
    schemaId: "builtin:oneagent.features",
    schemaVersion: "1.5.7",
    value: {
      enabled: true,
      key: "JAVA_REDIS_LETTUCE",
    },
  },
]