export const AUDIT_LOG = [
  {
    schemaId: "builtin:audit-log",
    schemaVersion: "1",
    scope: "environment",
    value: { enabled: true },
  },
];
